local functions = cardlike.require('functions')

cardlike.addDeck {
    id = 'ceramic_deck',
    name = 'Ceramic Deck',
    description = 'Start with a ' .. colorize(bold('Pottery'), functions.CERAMIC_CLR) .. ' and 1 less suit',

    image = 'images/ceramic_deck.png',

    onRunStart = function(ctx)

        cardlike.createJoker('pottery')

        local suit = ctx.state:getRandomSuit()

        for _, card in ipairs(ctx.state.allCards) do
            if card:getSuit() == suit then
                card:destroy()
            end
        end
    end
}