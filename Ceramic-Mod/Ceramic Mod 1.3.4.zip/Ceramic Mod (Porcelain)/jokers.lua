local functions = cardlike.require('functions')


cardlike.addJoker {
    id = 'pottery',
    readableName = 'Pottery',
    rarity = 'Rare',
    description = 'All ' .. bold('2s, 3s and 10s') .. ' become ' .. colorize(bold('Ceramic Cards'), functions.CERAMIC_CLR) .. ' if hand contains a ' .. bold('Three of a Kind'),
    image = 'images/pottery.png',

    triggers = {
        beforeAllCardsScored = function(joker, state, step, result)
            if not step.hand.contains.THREE_OF_A_KIND then return end

            local cards = step.hand.playedCards
            local triggered = false

            for _, card in ipairs(cards) do
                local rank = card:getRank()
                local card_type = card:getEnhancement()

                if card_type ~= 'ceramic:imp_ceramic' and card_type ~= 'imp_ceramic' and (rank ==  2 or rank == 3 or rank == 10) then
                    card:setEnhancement('ceramic')
                    card:punch()
                    triggered = true
                end
            end

            if triggered then
                joker:punch()
                joker:popup('Cup!', functions.CERAMIC_CLR)
            end

        end
    }
}


cardlike.addJoker {
    id = 'ceramic_joker',
    readableName = 'Ceramic Joker',
    rarity = 'Uncommon',
    
    description = function(r)
        local tri_count = functions.ceramic_tri_count()
        return 'Adds ' .. colorize(bold('X0.75 Points'), colors.CHIPS) .. ' for every 3 ' .. colorize(bold('Ceramic Cards'), functions.CERAMIC_CLR) .. ' in your deck\n(Currently '.. colorize('X' .. (1 + 0.75 * tri_count) .. ' Points', colors.CHIPS) .. ')'
    end,
    
    image = 'images/ceramic.png',

    triggers = {
        afterAllCardsScored = function(joker, state, step, result)
            result:add( xChips(1 + (0.75*functions.ceramic_tri_count())) )
        end
    },
}


