cardlike.require('jokers')
cardlike.require('enhancements')
cardlike.require('decks')


cardlike.filter('isFace', function(isFace, card)
    local card_type = card:getEnhancement()

    if card_type == 'imp_ceramic' or card_type == 'ceramic:imp_ceramic' then
        return true
    end
end
)