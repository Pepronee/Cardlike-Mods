local functions = {}
functions.CERAMIC_CLR = '#c7c1a9'

function functions.ceramic_tri_count()
    local cards = cardlike.state.allCards
    
    local ceramic_count = 0
    for _, card in ipairs(cards) do
        local card_type = card:getEnhancement()
        if card_type == 'ceramic:ceramic' or card_type == 'ceramic:imp_ceramic' then
            ceramic_count = ceramic_count + 1
        end
    end

    return ceramic_count // 3

end


return functions