local functions = cardlike.require('functions')

cardlike.addEnhancement {
    id = 'ceramic',
    readableName = 'Ceramic Card',
    triggerTime = 'scored',
    description = colorize(bold('X1.75 Points'), colors.CHIPS) .. '\nBut if hand is played with more than 3 cards, played ' .. colorize(bold('Ceramic Cards'), functions.CERAMIC_CLR) .. ' will break',
    image = 'images/ceramic.png',
    
    getBonus = function(state,card) return { xChips(1.75) } end,
    shouldDestroy = function(state,card) return #state.playedCards > 3 end,
}

cardlike.addEnhancement {
    id = 'imp_ceramic',
    readableName = 'Imperial Ceramic Card',
    triggerTime = 'scored',
    description = colorize(bold('X2 Points'), colors.CHIPS) .. ', Counts as a face card\nBut if hand is played with more than 3 cards, played ' .. colorize(bold('Ceramic Cards'), functions.CERAMIC_CLR) .. ' will break',
    image = 'images/imp_ceramic.png',
    
    getBonus = function(state,card) return { xChips(2) } end,
    shouldDestroy = function(state,card) return #state.playedCards > 3 end,
}